/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * (C) Copyright 2014-2016, Freescale Semiconductor, Inc.
 */

u32 cpu_mask(void);
int cpu_numcores(void);
