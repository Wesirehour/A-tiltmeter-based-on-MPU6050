/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * (C) Copyright 2004-2008
 * Texas Instruments, <www.ti.com>
 */
#ifndef _OMAP3_I2C_H_
#define _OMAP3_I2C_H_

#define I2C_DEFAULT_BASE	I2C_BASE1

#endif /* _OMAP3_I2C_H_ */
